"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { AppMenu } from "@/components/app-menu";
import { BottomNav } from "@/components/bottom-nav";
import { BrandMark } from "@/components/brand-mark";

const NAV_HEIGHT_PX = 56;

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const hideChrome =
    pathname.startsWith("/login") || pathname.startsWith("/auth");
  const isAdmin = pathname.startsWith("/admin");
  const showNav = !hideChrome && !isAdmin;

  return (
    <div className="min-h-dvh bg-black">
      <div
        className={`relative mx-auto flex min-h-dvh w-full flex-col overflow-x-clip bg-white text-black ${
          isAdmin ? "max-w-3xl" : "max-w-[430px]"
        }`}
      >
        {hideChrome ? null : (
          <header className="sticky top-0 z-40 border-b border-neutral-800 bg-black pt-[env(safe-area-inset-top,0px)]">
            <div className="flex items-center justify-between gap-2 px-4 py-3">
              <Link
                href="/"
                className="flex min-w-0 items-center gap-2 text-[21px] font-semibold tracking-tight text-white"
              >
                <BrandMark className="h-7 w-7 shrink-0" />
                NEWFIND
              </Link>
              <AppMenu />
            </div>
          </header>
        )}
        <main
          className="relative z-0 flex-1"
          style={
            showNav
              ? {
                  paddingBottom: `calc(${NAV_HEIGHT_PX}px + env(safe-area-inset-bottom, 0px))`,
                }
              : undefined
          }
        >
          {children}
        </main>
        {showNav ? <BottomNav /> : null}
      </div>
    </div>
  );
}
